import 'regenerator-runtime';
import './jumbotron-component.js';
import '../styles/main.css';
import './restaurant-card.js';
import './footer-component.js';

console.log('Hello Coders! :)');
