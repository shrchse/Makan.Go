import restaurants from '../DATA.json';

const sectionMain = document.getElementById('card-section');
sectionMain.innerHTML = '';

const tree = restaurants.restaurants;
tree.forEach(element => {
  sectionMain.innerHTML += 
  `<div class="card" tabindex="0" id="maincontent">
      <div class="card-image">
        <img src="${element.pictureId}" alt="Gambar Restaurant ${element.name}" width="100%">
      </div>
      <div class="card-content">
        <div class="card-title"><h1>${element.name}</h1></div>
        <div class="card-sub"><h2>${element.city}</h2></div>
        <div class="card-sub">
          <img src="./images/heros/Star.png" alt="Rating" width="18">
          | ${element.rating}
        </div>
      </div>
    </div>`
});
