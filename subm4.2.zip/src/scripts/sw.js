const navDrawerButton = document.querySelector('#hamburger');
const navMenu = document.querySelector('#nav');
const navList = document.querySelector('#nav-ul');
const closeElement = document.querySelector('body');

navDrawerButton.addEventListener('click', event =>{
    navMenu.classList.toggle('open');
    navList.classList.toggle('open');
    event.stopPropagation();
})
