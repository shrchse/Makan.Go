fetch("../DATA.json")
    .then()